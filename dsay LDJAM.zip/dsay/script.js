var strongBook; // current loc
var scope = [];
var locationRed = ['bed', 'room', 'outside', 'blacksmith', 'cellar', 'root clearing'];
var daily = new Date();
var encompassesExp = 0;
let lexicon = 0;
var gold = 0;
var xspeed = 2;
var yspeed = 2;
var memory = [];
let story = [];

function imagine(idea) {
    if (idea == "Breadwin") {
        gold += 10000;

    }
    if (idea == undefined) {

        return "unknowing";
    }

    memory.push(idea);
    console.log(memory.length);
    if (memory.length >= 10) {
        newston(memory);
        document.getElementById('sus4').innerHTML = story;
        memory = [];
    }
    document.getElementById('suss').innerHTML = memory;
    document.getElementById('sus').innerHTML = idea;
    document.getElementById('sus2').innerHTML = encompassesExp;
    document.getElementById('sus3').innerHTML = gold;
    let experience = 0;
    if (idea == "good"){
        encompassesExp++;
        yspeed++;
        console.log(encompassesExp);
    }
    if (idea == "retortive") {
        lexicon++;
        yspeed++;
        xspeed++;
        encompassesExp++;
        // maybe a fight?                
    }
    if (idea == "excelling") {
        // dex goes up
        //
        encompassesExp++;
        xspeed++;
        yspeed++;
        // gram item
    }
    if (idea == "prosperous") {
        encompassesExp++;
        gold++;
        yspeed++;
        xspeed++;

    }
    if (idea == "greedy") {
        gold++;
        xspeed++;
        yspeed++;
    }
    if (idea == "malevil") {
        // start a fight
        yspeed++;
        xspeed++;
    }
    if (idea == "exalted") {
        // end evil entirely
        // stops fight
        yspeed++;
        xspeed++;
    }
    if (idea == "unknowing") {
        // lots, you  die in a fight
        // you lose your roll
        yspeed++;
        xspeed++; 
    }

}

function newston(memory) {
    if (memory == ['good', 'good', 'good', 'good', 'good', 'good', 'good', 'good', 'good', 'good']) {
        story = "Good";
        encompassesExp += 10000000;
    }
    if (memory == ['']) {
        story = "Not started";
    }
    if (xspeed == 0) {
        story = "You ain't going nowhere";
    }
    if (xspeed >= 10) {
        story = "You wake up in bed."
        strongBook = locationRed[0];
    }
    if (xspeed >= 40 && strongBook == locationRed[0]) {
        story = "You have time to wake up and decide to take in your surroundings. It's a simple little shack that doesn't go anywhere since you built it right. You've been a strong builder ever since I've known you.";
        strongBook = locationRed[1];
    }
    if (xspeed >= 60 && strongBook == locationRed[1]) {
        story = "You have time to wake up and decide to take in your surroundings. You walk out of your shack to the blacksmith to work for a while.";
        strongBook = locationRed[2];
    }
}

//function story(mem) {
//    // needed transversal
//    let i;
//    let e;
//    function iOverE(){
//        // keep memory over detail
//    }
//    // i remember fighting a tree on the way here and because of that i'm permadeaf
//    // until a wizard healed me
//    let memory = mem;
//    let seriousDebate = xspeed + yspeed;
//    if (memory > seriousDebate) {
//        // memory serves
//        // you win the race and you win the race again
//
//
//
//    }
//
//}

setInterval(function grow() {
    let i = Math.floor(Math.random() * 4567) + 1;
    console.log(i + "i:");
    let answ;
    if (i < 2) {
        answ = "#1";
    }
    if (i > 3) {
        answ = "Breadwin";
    }
    if (i > 190) {
        answ = "good";
    }
    if (i > 480) {
        answ = "retortive";
    }
    if (i > 662) {
        answ = "excelling";
    }
    if (i > 852) {
        answ = "prosperous";
    }
    if (i > 1052) {
        answ = "greedy";

    }
    if (i > 2044) {
        answ = "malevil";

    }
    if (i > 2550) {
        answ = "exalted";
    }
    if (i > 3050){
        answ = "unknowing";
    }
    imagine(answ);
    console.log(xspeed, yspeed);
}, 1000);

// we can function on a spectrum basically
// good, retortive, excelling, prosperous, greedy, malevil, exalted, unknowing
// good 4 times in a row means that he beat the computer war
// retortive means that he went to war and survived if he got good rolls
// excelling means that he got good grades
// prosperous means he got good instincts
// greedy means he's wasting time
// malevil means he's wasting more time
// exalted means he's cast out of his crew
// unknowing means anything could happen
// XSPEED AND YSPEED
